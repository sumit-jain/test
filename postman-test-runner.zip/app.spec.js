process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
const tags = require("mocha-tags");
const chai = require("chai");
chai.use(require("chai-match-pattern"));
chai.use(require("chai-http"));
const expect = chai.expect;
const moxios = require("moxios");
const axios = require('axios');
if (!process.env.TEST_URL) {
  var app = require("./app");
}
const testScenarios = require("./app.spec.json");
var request;
before(async function () {
  if (process.env.TEST_URL) {
    console.info("TEST_URL is", process.env.TEST_URL);
    request = await chai.request(process.env.TEST_URL).keepOpen();
  } else {
    request = await chai.request(app).keepOpen();
  }
});
after(async function () {
  await request.close();
});
// loop for tests
testScenarios.forEach(scenario => {
    // loop for scenarios
    before(async () => {
      if (!process.env.TEST_URL && scenario.mockData) {
        moxios.install(axios)
        console.info("setting up moxios");
        scenario.mockData.forEach(m => {
          moxios.stubRequest(m.input, m.output);
        });
      }
    })
    after(() => {
      if (!process.env.TEST_URL) moxios.uninstall(axios);
    })
    // tags
    tags.apply(this, scenario.testType ? scenario.testType : ["integration", "regression", "validation", "smoke", "unit"])
      // it
      .it(`${scenario.testCaseName} : ${scenario.methodName} ${scenario.processInput} - ${scenario.status}`, function (done) {
        request
          .get(scenario.processInput)
          .set("Accept", "application/json")
          .set("Content-Type", "application/json")
          .set(scenario.headers)
          .then((res) => {
            try {
              expect(res).to.have.status(scenario.status);
              expect(res).to.have.header("Content-Type", /json/);
              if (scenario.status >= 400) {
                // in error scenarios
                expect(res.body.requestData).to.eql(scenario.requestData);
                expect(res.body.userMessage).to.eql(scenario.errorMessage);
              } else {
                // in success scenarios
                if (scenario.responseData) {
                  expect(
                    scenario.wrappedResponse ? res.body.data : res.body
                  ).to.eql(scenario.responseData);
                } else if (scenario.responseAttribute) {
                  expect(
                    scenario.wrappedResponse ? res.body.data : res.body
                  ).to.have.property(scenario.responseAttribute);
                }

              }
              done();
            } catch (error) {
              done(error);
            }
          });

      });
});