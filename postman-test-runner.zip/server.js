const app = require("./app");
const config = require("./config");

app.listen(config.PORT, function () {
    console.info('app started at http://localhost:' + config.PORT + '...');
});
