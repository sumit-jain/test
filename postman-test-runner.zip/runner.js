var express = require("express");
var router = express.Router();
var fs = require("fs");
const newman = require("newman");

const collectionFolder = `${__dirname}/postman/collections/`;
const environmentFolder = `${__dirname}/postman/environment/`;
const templateFolder = `${__dirname}/postman/template/`;
const reportFolder = `${__dirname}/report/`;

router.get("/collections", (req, res) => {
  const files = fs.readdirSync(collectionFolder);
  const collections = readCollection(files);
  res.send(collections);
});

router.post("/:environment/collection/run", (req, res) => {
  try {
    runCollection(req.body, req.params.environment);
    res.status(200).send("success");
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get("/:environment/report", (req, res) => {
  try {
    if (req.params.environment) {
      const files = fs.readdirSync(`${reportFolder}/${req.params.environment}`);
      const reports = readReports(files, req.params.environment);
      res.send(reports);
    } else {
      res.status(400).send("bad request");
    }
  } catch (error) {
    res.status(500).send(error);
  }
});

function readCollection(files) {
  const collections = [];
  files.forEach(function (fileName) {
    var collectionContent = fs.readFileSync(
      `${collectionFolder}/${fileName}`,
      "utf8"
    );
    const collectionJSON = JSON.parse(collectionContent);
    const requests = collectionJSON.item.map((item) => {
      return item.name;
    });
    collections.push({
      name: collectionJSON.info.name,
      fileName: fileName,
      expanded: false,
      checked: false,
      selected: [],
      requests: requests,
    });
  });
  return collections;
}

function runCollection(collections, environment) {
  var done = false;
  for (const item of collections) {
    newman
      .run({
        collection: require(`${collectionFolder}${item.collection}`),
        reporters: "html",
        environment: require(`${environmentFolder}${environment}.json`),
        folder: item.folder,
        iterationCount: 1,
        reporter: {
          html: {
            export: `./report/${environment}/${item.collection}.html`,
            template: `${templateFolder}/sample.hbs`,
          },
        },
      })
      .on("done", function () {
        done = true;
      });
    require("deasync").loopWhile(function () {
      return !done;
    });
    done = false;
  }
}

function readReports(files, environment) {
  const reports = [];
  files.forEach(function (fileName) {
    var reportContent = fs.readFileSync(`${reportFolder}${environment}/${fileName}`, "utf8");
    reports.push(reportContent);
  });
  return reports;
}

module.exports = router;
