# Boilerplate for VueJS deploying to PCF

This boilerplate project gets utilized by automation platform for creating new repo for this particular type of repo

[SonarQube Analysis](https://sonarqube.service.edp.t-mobile.com/dashboard?id=TMPL-VUEJSPCF%3Amaster)

## Run & Deploy App

```bash
    # check, internally runs clean install lint-dev test-dev analyze-dev
    npm run check

    # run the app locally at http://localhost:3000
    npm run local

    # deploy, internally runs make/clean/install-prod
    npm run deploy
```