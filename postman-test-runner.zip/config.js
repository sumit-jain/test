const fs = require("fs");
const cfenv = require("cfenv");
var config = {};
var env = (process.env && process.env.PORT)
  ? process.env
  : fs.existsSync("./env.json")
    ? JSON.parse(fs.readFileSync("./env.json"))
    : {};

config.ERR_NUMBER_ONLY = {
  code: 406,
  message: env.ERR_NUMBER_ONLY || "use numbers only"
};
config.ERR_NOT_IMPLEMENTED = {
  code: 501,
  message: env.ERR_NOT_IMPLEMENTED || "not implemented"
};
config.ERR_API_CALL_FAILURE = {
  code: 424,
  message: env.ERR_API_CALL_FAILURE || "got error response from api"
};
config.ENV_ID = env.ENV_ID || "test-env";
config.ENV_TIER_ID = env.ENV_TIER_ID || "test";
config.ROOT_PATH = __dirname;
config.APPVERSION = env.APPVERSION || "1.0.0";
config.PORT = env.PORT || 3000;
config.STATUS_UP = "UP";
config.STATUS_DOWN = "DOWN";
config.USER_DATA = JSON.parse(fs.readFileSync("./user-data.json"));
config.BASE_API = env.BASE_API || "http://localhost:3000";
config.ui_baseapiurl = env.ui_baseapiurl || "http://localhost:3000";
config.APP_JS_PATH = env.APP_JS_PATH || "app.js";
config.GTM_HOST_NAME = env.GTM_HOST_NAME;
const _appEnv = env.VCAP_APPLICATION
  ? cfenv.getAppEnv()
  : cfenv.getAppEnv({ vcap: JSON.parse(fs.readFileSync("./env.json")) });
config.url = (_appEnv.isLocal) ? 'localhost:' + config.PORT : _appEnv.url;
module.exports = config;