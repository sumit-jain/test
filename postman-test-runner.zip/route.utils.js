var route_utils = {};

var _EvalExpression = function(expression, data) {
  if (expression && expression.length > 0) {
    var regex = /{([^}]+)}/g;
    var keywords = expression.match(regex);
    var params = Object.assign({}, data);
    if (keywords) {
      for (var i = 0; i < keywords.length; i++) {
        var key = keywords[i].replace("{", "").replace("}", "");
        if (params[key] != undefined && params[key] != "") {
          expression = expression.replace(keywords[i], params[key].toString());
        } else {
          expression = expression.replace(keywords[i], "");
        }
      }
    }
    return expression;
  } else return null;
};

route_utils.BuildURL = function(url, params) {
  return _EvalExpression(url, params);
};

var _Replace = function(str) {
  if (str && str.length > 0) {
    str = str.slice(9, str.length - 1);
    var params = str.split(",");
    str = params[0].replace(params[1], params[2] == "pipe" ? "|" : params[2]);
    return str;
  } else return "";
};

route_utils.BuildHeader = function(service, expression, params) {
  var result = _EvalExpression(expression, params);
  if (result == null) return null;
  var header = {};
  var headers = result.split("#");
  for (var i = 0; i < headers.length; i++) {
    var headerName = headers[i].split("|")[0];
    var headerValue = headers[i].split("|")[1];
    if (headerValue.indexOf("_ENCRYPT") > -1) {
      // ENCRYPT
    }
    if (headerValue.indexOf("_C2Auth") > -1) {
      // headerValue = _C2Auth(service["Credential"]);
    }
    if (headerValue.indexOf("_REPLACE") > -1) {
      headerValue = _Replace(headerValue);
    }
    if (headerValue != undefined && headerValue != "")
      header[headerName] = headerValue;
  }
  return header.length == 0 ? null : header;
};

module.exports = route_utils;