const route_utils = require("./route.utils");
const route_config = require("./route.config");
const config = require("./config");
const axios = require('axios');

module.exports = app => {
  app.get("/api/:service/:key", (req, res) => {
    var parsedData = {};
    try {
      var baseURL = route_config.ServiceKey[req.params.service]["BaseURL"];
      var url = route_utils.BuildURL(
        route_config.ServiceKey[req.params.service]["GET"][req.params.key]["Path"],
        req.query
      );
      var headers = route_utils.BuildHeader(
        route_config.ServiceKey[req.params.service],
        route_config.ServiceKey[req.params.service]["GET"][req.params.key]["Header"],
        req.headers
      );
      var settings = {
        baseURL: baseURL
      };
      
      if (headers) {
        settings["headers"] = headers;
      }
      axios
      .create(settings)
      .get(url)
      .then(function(response) {
          try {
            parsedData = route_config.ServiceKey[req.params.service]["WrappedResponse"] === true ? 
                            response.data.data :  response.data;
            res.status(200).json(parsedData);
          } catch (e) {
            console.error(e.message);
            res.status(500).send(e.message);
          }
        })
        .catch(function(error) {
          console.error(config.ERR_API_CALL_FAILURE, baseURL+url,error);
          res.status(error.response.status).send(error.response.data);
        });
    } catch (e) {
      console.error(e);
      res.status(417).send(e);
    }
  });

  app.get("/user", async (_req, _res, _next) => {
    try {
      if(_req.query.error){
        throw {error:_req.query.error};
      } else {
        let data = config.USER_DATA.map((el) => {
          return el.name
        });
        if (_req.query.name) {
          data = data.filter((r) => {
            return r.toLocaleLowerCase().includes(_req.query.name)
          })
        }
        setTimeout(() => {
          _res
            .status(200)
            .json(data);
        }, 500)
      }
    } catch (e) {
      console.error(e);
      _res.status(500).send(e);
    }
  });
};
