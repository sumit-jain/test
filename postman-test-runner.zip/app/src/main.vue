<script>
import Vue from "vue";
import vueCustomElement from "vue-custom-element";
import testRunner from "./components/test-runner";

Vue.config.devtools = true;

//custom element factory registration
Vue.use(vueCustomElement);

Vue.customElement("test-tag", testRunner);

export default {};
</script>
