<template>
  <div class="navbar">
    <span class="logo-text">Postman collection  runner</span>
    <button @click="runTest">Run</button>
  </div>
</template>
<script>
export default {
  name: "Header",
  methods: {
    runTest() {
      this.$emit("run-selected-test");
    },
  },
};
</script>
<style scoped>
.navbar {
  overflow: hidden;
  background-color: #dd147c;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 12;
  width: 100%;
}

.logo-text {
  float: left;
  display: block;
  background-color: #dd147c;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  border: none;
  font-size: 20px;
}

.navbar button {
  float: right;
  display: block;
  background-color: #dd147c;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  border: none;
  text-decoration: none;
  font-size: 17px;
  cursor: pointer;
}

.navbar button:hover {
  text-decoration: underline;
}
</style>
