<template>
  <div>
    <Header v-on:run-selected-test="runCollection" />
    <Sidebar v-on:change-env="environmentChanged" ref="sidebar" />
    <div class="content">
      <div
        v-for="(content, index) in reportContent"
        :key="index"
        class="item"
        v-html="content"
      ></div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Header from "./header.vue";
import Sidebar from "./sidebar.vue";
export default {
  name: "test-runner",
  components: { Header, Sidebar },
  data() {
    return {
      reportContent: "",
      environment: "dev",
    };
  },
  mounted() {
    this.showResult();
  },
  methods: {
    async runCollection() {
      const result = await this.$refs.sidebar.runSelectedCollectionRequests();
      if (result) {
        this.showResult();
      }
    },
    showResult() {
      axios
        .get(`http://localhost:3000/runner/${this.environment}/report`)
        .then((result) => {
          this.reportContent = result.data;
        });
    },
    environmentChanged(env) {
      this.environment = env;
      this.showResult();
    },
  },
};
</script>
<style scoped>
.content {
  position: absolute;
  left: 320px;
  top: 92px;
  right: 0;
  bottom: 0;
  overflow: hidden;
  overflow-y: auto;
}

.content .item {
  border: 1px solid #ddd;
  border-radius: 5px;
  margin-top: 1rem;
}

.collapsible-content {
  display: none;
}

.wrap-collabsible {
  margin: 1.2rem 0;
}

.lbl-toggle {
  display: block;
  font-weight: bold;
  font-family: monospace;
  font-size: 1.2rem;
  text-transform: uppercase;
  text-align: center;
  padding: 1rem;
  color: #ddd;
  background: #dd147c;
  cursor: pointer;
  border-radius: 7px;
  transition: all 0.25s ease-out;
}

.lbl-toggle:hover {
  color: #fff;
}

.lbl-toggle::before {
  content: " ";
  display: inline-block;
  border-top: 5px solid transparent;
  border-bottom: 5px solid transparent;
  border-left: 5px solid currentColor;
  vertical-align: middle;
  margin-right: 0.7rem;
  transform: translateY(-2px);
  transition: transform 0.2s ease-out;
}

.toggle:checked + .lbl-toggle::before {
  transform: rotate(90deg) translateX(-3px);
}

.collapsible-content {
  max-height: 0px;
  overflow: hidden;
  transition: max-height 0.25s ease-in-out;
}

.toggle:checked + .lbl-toggle + .collapsible-content {
  max-height: 100%;
}

.toggle:checked + .lbl-toggle {
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.collapsible-content .content-inner {
  background: rgba(0, 105, 255, 0.2);
  border-bottom: 1px solid rgba(0, 105, 255, 0.45);
  border-bottom-left-radius: 7px;
  border-bottom-right-radius: 7px;
  padding: 0.5rem 1rem;
}

.collapsible-content p {
  margin-bottom: 0;
}
</style>
