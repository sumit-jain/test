<template>
  <div id="app">
    <div class="toaster" v-if="toaster">
      Thank you for submitting
    </div>
    <div class="form-wrap">
      <form>
        <div class="form-group" id="name-input">
          <label for="name">Your Name : </label>
          <input
            type="text"
            id="name"
            v-model="form.name"
            placeholder="Enter name"
            :class="{ error: !nameValidation }"
          />
        </div>

        <div class="form-group" id="email-input">
          <label for="email">Email address: </label>
          <input
            type="text"
            id="email"
            v-model="form.email"
            placeholder="Enter email"
          />
        </div>

        <div class="form-group" id="requested-by-select">
          <label for="requested-by"> Requested By: </label>
          <vue-select
            :class="['requested-by-select', { error: !requestedByValidation }]"
            style="width:400px;height:30px;"
            :placeholder="'Select Requested By'"
            maxHeight="300px"
            id="requested-by"
            v-model="form.requestedBy"
            :options="requestedByOptObj"
            @search="debounceGetRequestedBy"
            :filterable="false"
          />
          <p class="error-msg" v-if="!requestedByValidation">
            Requested By is required
          </p>
        </div>

        <div class="form-group" id="requested-for-select">
          <label for="requested-by"> Requested For: </label>
          <vue-select
            class="requested-for-select"
            style="width:400px;height:30px;"
            :placeholder="'Select Requested For'"
            :disabled="!requestedByValidation"
            maxHeight="300px"
            id="requested-for"
            v-model="form.requestedFor"
            :options="requestedForOptObj"
            @search="debounceGetRequestedFor"
            :filterable="false"
          />
        </div>

        <div class="form-group" id="description-textarea">
          <textarea
            placeholder="Description"
            id="description"
            v-model="form.description"
            cols="6"
            rows="3"
          ></textarea>
        </div>

        <div class="form-group" id="checkbox-input">
          <span>
            <input
              type="checkbox"
              name="checkbox-one"
              id="checkbox-one"
              value="checkbox-one"
              v-model="form.checked"
            />
            <label for="checkbox-one">Check me out</label>
          </span>
          <span>
            <input
              type="checkbox"
              name="checkbox-two"
              id="checkbox-two"
              value="checkbox-two"
              v-model="form.checked"
              disabled="disabled"
            />
            <label for="checkbox-two">Check that out</label>
          </span>
        </div>

        <div class="form-group" id="radio-input">
          <span v-for="option in options" :key="option.item">
            <input
              v-on:change="changeOption"
              type="radio"
              name="option"
              :id="option.item"
              v-model="radioValue"
              :value="option.item"
              :disabled="option.notEnabled"
            />
            <label :for="option.item">{{ option.name }}</label>
          </span>
          <p class="selected-txt">
              You have selected : <span class="selected-option"> {{selectedOption}} </span>
          </p>
        </div>

        <button
          type="submit"
          class="submit"
          :disabled="!isSubmitEnable"
          @click="onSubmit"
        >
          Submit
        </button>
        <button type="reset" @click="onReset" class="cancel">Cancel</button>
      </form>
    </div>
  </div>
</template>

<script>
import debounce from "lodash/debounce";
import axios from "axios";
import vSelect from "vue-select";
const tmoAppConfig = "##Configvalues##";

export default {
  name: "App",
  components: { "vue-select": vSelect },
  data() {
    return {
      selectedOption:"",
      form: {
        email: "",
        name: "",
        requestedBy: null,
        requestedFor: null,
        checked: [],
        description: "",
      },
      requestedByOpt: null,
      requestedByOptObj: [],
      requestedForOpt: null,
      requestedForOptObj: [],
      options: [
        { item: "A", name: "Option A" },
        { item: "B", name: "Option B" },
        { item: "C", name: "Option C", notEnabled: true },
        { item: "D", name: "Option D" },
      ],
      radioValue: "",
      toaster: false,
    };
  },
  created(){
        axios.defaults.baseURL = tmoAppConfig.baseapiurl || '//localhost:3000';
  },
  mounted() {
        this.$root.$on('update:option', (radioValue)=>{
            this.selectedOption = radioValue
        })
    },
  methods: {
    onSubmit(evt) {
      evt.preventDefault();
      this.toaster = true;
      setTimeout(() => {
        this.toaster = false;
        this.onReset(evt);
      }, 5000);
    },
    onReset(evt) {
      evt.preventDefault();
      this.form.name = "";
      this.form.email = "";
      this.form.requestedBy = null;
      this.form.requestedFor = null;
      this.form.description = "";
      this.form.checked = [];
      this.radioValue = "";
      this.changeOption();
    },
    debounceGetRequestedBy: debounce(
      function(searchText, loading, vm) {
        if (searchText.trim() != "") {
          axios
            .get(`/api/sample/user?name=${searchText}`)
            .then((response) => {
              this.requestedByOptObj = response.data.data;
            });
        }
      },
      0,
      { trailing: true, maxWait: 8000, leading: false }
    ),
    debounceGetRequestedFor: debounce(
      function(searchText, loading, vm) {
        if (searchText.trim() != "") {
          axios
            .get(`/api/sample/user?name=${searchText}`)
            .then((response) => {
              this.requestedForOptObj = response.data.data;
            });
        }
      },
      0,
      { trailing: true, maxWait: 8000, leading: false }
    ),

    changeOption() {
      this.$root.$emit("update:option", this.radioValue);
    },
  },

  computed: {
    nameValidation() {
      return this.form.name.trim() !== "";
    },
    requestedByValidation() {
      return this.form.requestedBy !== null;
    },
    isSubmitEnable() {
      return (
        this.form.requestedBy !== "" &&
        this.form.requestedBy !== null &&
        this.form.name.trim() !== ""
      );
    },
  }
};
</script>

<style>
@import "../../node_modules/vue-select/dist/vue-select.css";
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.form-wrap {
  max-width: 600px;
  width: 100%;
  margin: 0 auto;
  text-align: left;
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
}
.form-wrap .submit-button {
  margin-right: 10px;
}

.ag-theme-alpine {
  height: 488px;
  width: 1000px;
  margin: 20px auto;
}
.requested-by-select .dropdown-menu,
.requested-for-select .dropdown-menu {
  display: inline-block;
  padding: 0;
  width: 100%;
  margin-top: 6px;
  box-shadow: 0px 3px 6px -3px black;
}
.dropdown.v-select.requested-by-select,
.requested-by-select .dropdown-toggle,
#requested-by,
.dropdown.v-select.requested-for-select,
.requested-for-select .dropdown-toggle,
#requested-for {
  width: 100%;
  min-width: 100%;
  height: auto !important;
}
.dropdown-toggle:after {
  display: none;
}
.requested-by-select .dropdown-menu li a,
.requested-for-select .dropdown-menu li a {
  padding: 5px 10px;
}
.requested-by-select .form-control,
.requested-for-select .form-control {
  font-size: 1rem !important;
}

.form-group {
  padding: 5px 0;
  margin-bottom: 10px;
}
.form-group label {
  display: block;
  padding: 5px 0;
}
.v-select input[type="search"], .v-select input[type="search"]:focus {
  position: static;
  margin: 4px 0 0;
  height: auto;
}
#radio-input span,
#checkbox-input span {
  display: inline-block;
  margin-right: 10px;
}
#radio-input label {
  display: inline-block;
  padding:0 0 0 5px;
}
#radio-input input:disabled + label{
  opacity: 0.5;
}

#checkbox-input label {
  display: inline-block;
}

[type="radio"]:checked, [type="radio"]:not(:checked) {
  position: static;
}
.form-group > input,
.form-group textarea {
  border: 1px solid #ccc;
  display: block;
  border-radius: 5px;
  padding: 10px;
  width: 100%;
  box-sizing: border-box;
  height: auto;
}

.submit,
.cancel {
  color: #fff;
  border-color: #007bff;
  background-color: #007bff;
  display: inline-block;
  font-weight: 400;
  text-align: center;
  vertical-align: middle;
  border: 1px solid #007bff;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out,
    border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
  cursor: pointer;
}
.submit:hover {
  background-color: #0069d9;
  border-color: #0062cc;
}
.submit:disabled {
  background-color: #007bff;
  border-color: #007bff;
  opacity: 0.65;
}
.cancel {
  color: #fff;
  background-color: #dc3545;
  border-color: #dc3545;
  margin-left: 5px;
}
.cancel:hover {
  background-color: #c82333;
  border-color: #bd2130;
}
.error,
.error .vs__dropdown-toggle {
  border-color: #f00 !important;
}
.error-msg {
  font-size: 12px;
  margin: 5px 0 0;
  color: #f00;
}
.toaster {
  position: fixed;
  top: 5px;
  right: 5px;
  background: #4fc573;
  padding: 5px 10px;
  width: 250px;
  text-align: center;
  color: #fff;
}
[type="radio"] + label:after, [type="radio"] + label:before {display: none;}

</style>
