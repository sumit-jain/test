<template>
  <div class="sidebar">
    <div class="test-list-header">
      <div class="header-list">
        <h3>Collections</h3>
        <Loader v-if="loading" />
      </div>
      <input
        type="radio"
        id="Dev"
        name="env-group"
        value="dev"
        v-model="environment"
      />
      <label for="Dev" class="mr-4">Dev</label>
      <input
        type="radio"
        id="Stage"
        name="env-group"
        value="stage"
        v-model="environment"
      />
      <label for="Stage" class="mr-4">Stage</label>
      <input
        type="radio"
        id="Prod"
        name="env-group"
        value="prod"
        v-model="environment"
      />
      <label for="Prod">Prod</label>
    </div>
    <ul class="test-list">
      <li v-for="(collection, index) in collections" :key="index">
        <input
          type="checkbox"
          :name="collection.name"
          v-model="collection.checked"
          :disabled="loading"
          @click="selectAllRequest(collection)"
        />
        <label class="bold" @click="toggleRequests(index)">
          {{ collection.name }}</label
        >

        <ul v-if="collection.expanded" class="child-list">
          <li v-for="(request, idx) in collection.requests" :key="idx">
            <input
              type="checkbox"
              v-model="collection.selected"
              :disabled="loading"
              :value="`${collection.fileName}_${idx}`"
              @change="requestSelectionChange(collection)"
            />
            {{ request }}
          </li>
        </ul>
      </li>
    </ul>
  </div>
</template>
<script>
import axios from "axios";
import Loader from "./loader.vue";
export default {
  name: "test-runner",
  components: { Loader },
  data() {
    return {
      collections: [],
      environment: "dev",
      loading: false,
    };
  },
  created() {},
  mounted() {
    axios
      .get("http://localhost:3000/runner/collections")
      .then((result) => {
        this.collections = result.data;
      })
      .catch((error) => console.log(error));
  },
  methods: {
    toggleRequests(index) {
      this.collections[index].expanded = !this.collections[index].expanded;
    },
    selectAllRequest(collection) {
      collection.selected = [];
      if (!collection.checked) {
        for (let index = 0; index < collection.requests.length; index++) {
          collection.selected.push(collection.fileName + "_" + index);
        }
      }
    },
    requestSelectionChange(collection) {
      collection.checked =
        collection.requests.length === collection.selected.length;
    },
    runSelectedCollectionRequests() {
      if (!this.loading) {
        const selectedRequests = [];
        for (const collection of this.collections) {
          if (collection.requests.length === collection.selected.length) {
            selectedRequests.push({
              collection: collection.fileName,
            });
          } else {
            for (const request of collection.selected) {
              var index = request.lastIndexOf("_");
              var result = request.substr(index + 1);
              selectedRequests.push({
                collection: collection.fileName,
                folder: collection.requests[result],
              });
            }
          }
        }
        if (selectedRequests.length > 0) {
          this.loading = true;
          return axios
            .post(
              `http://localhost:3000/runner/${this.environment}/collection/run`,
              selectedRequests
            )
            .then(() => {
              this.loading = false;
              return true;
            })
            .catch((error) => console.log(error));
        } else {
          alert("Please select test(s) to run...");
        }
      }
      return false;
    },
  },
  watch: {
    environment: function (val) {
       this.$emit("change-env", val);
    },
  },
};
</script>

<style scoped>
.sidebar {
  border: 1px solid;
  left: 0;
  z-index: 0;
  position: absolute;
  left: 0;
  top: 50px;
  bottom: 0;
}
.bold {
  font-weight: 700;
}
.test-list {
  margin-left: -2rem;
  padding-right: 1rem;
  overflow: hidden;
  height: 75vh;
  overflow-y: auto;
}
.header-list {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.test-list li {
  width: 260px;
}
.child-list li {
  width: 200px;
}
.test-list li:not(:last-child) {
  border-bottom: 1px solid;
}
.test-list-header {
  margin: 10px;
}
.mr-4 {
  margin-right: 1rem;
}
html,
body {
  overflow: hidden;
}
</style>
