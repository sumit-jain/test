module.exports = {
  chainWebpack: config => {
    config.optimization.delete('splitChunks');
  },
  configureWebpack: {
    entry: './src/main.vue',
    output: {
      filename:'app.js'
    }
  },
  css: {
    extract: false
  },
  outputDir: '../public'
};
