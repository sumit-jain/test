const testComponents = {"sample_vue":""};
jest.setTimeout(30000);
const fs = require('fs');
if (!fs.existsSync('screenshots')) {
  fs.mkdirSync('screenshots');
}
for (var componentName in testComponents) {
  const testCases = require(`./${componentName}.test.json`);
  describe("", () => {
    beforeEach(async () => {
      await page.goto(process.env.TEST_URL || "http://localhost:3000", {
        waitUntil: "domcontentloaded"
      });
    });
    test.each(testCases.map(t => [`${t.name} : ${t.methodName} ${componentName} - ${t.status}`, t]))("%s", async (name, testCase) => {
      let propTxt = '';
      for (var prop in testCase.options.propsData) {
        propTxt += `${prop}="${testCase.options.propsData[prop]}" `
      };
      await page.$eval('#test-app', (e, tag, props) => {
        e.innerHTML = `<${tag} ${props}></${tag}>`
      }, testCase.tag, propTxt);
      await page.waitForSelector(testCase.tag)
      for (var j = 0; j < testCase.steps.length; j++) {
        let scenario = testCase.steps[j];
        if (!scenario.types || scenario.types.indexOf(process.env.TEST_TYPE) > -1) {
          for (var i = 0; i < scenario.actions.length; i++) {
            let step = scenario.actions[i];
            await page.waitForSelector(step.selector);
            switch (step.action) {
              case "input":
                await expect(page).toFill(step.selector, step.options.value);
                break;
              case "mousedown":
              case "focus":
              case "click":
                await expect(page).toClick(step.selector);
                break;
              default:
                await page[step.action](step.selector);
                break;
            }
          }
          await page.screenshot({
            path: `screenshots/${testCase.name}-${scenario.name}.png`, fullPage: true});
          for (var i = 0; i < scenario.expectations.length; i++) {
            let ex = scenario.expectations[i];
            switch (ex.type) {
              case "axios":
                expect(mockAxios[ex.method], scenario.name).toHaveBeenCalledWith( ex.url, ex.requestit);
                break;
              case "control":
                switch (ex.property) {
                  case "innerText":
                  case "exists":
                    await expect(page, scenario.name).toMatchElement(ex.selector, ex.options);
                    break;
                  case "disabled":
                    await expect(page, scenario.name).toMatchElement(`${ex.selector}[disabled]`, ex.options);
                    break;
                  case "hasAttribute":
                    await expect(page, scenario.name).toMatchElement(`${ex.selector}[${ex.options.expected}]`, ex.options);
                    break;
                  case "doesNotHaveAttribute":
                    await expect(page, scenario.name).toMatchElement(`${ex.selector}:not([${ex.options.expected}])`, ex.options);
                    break;
                }
                break;
            }
          }
        }
      }
    });
  });
}
