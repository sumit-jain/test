const sinon = require("sinon");
const server = sinon.createFakeServer({ autoRespond: true });
server.respondWith(/config\/settings/, (xhr, id) => {
  console.log("got settings call");
  xhr.respond(
    200,
    { "Content-Type": "application/json" },
    '{"ui_baseapiurl":"//localhost:3000"}'
  );
});
// server.respondWith(/health/,(xhr,id)=>{
//     console.log('got health call')
//     xhr.respond(200, {"Content-Type":"application/json"}, '{"status":"UP"}');
// });
module.exports.server = server;
