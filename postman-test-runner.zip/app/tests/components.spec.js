import VueTestUtils from "@vue/test-utils";
import flushPromises from "flush-promises";
import { server } from "./server.mock";
import * as testComponents from "./components.js";
jest.mock("axios");
const axios = require("axios");
for (var componentName in testComponents) {
  const testCases = require(`./${componentName}.test.json`);
  describe("", () => {
    afterAll(() => {
      server.restore();
      axios.get.mockReset();
    });
    testCases.forEach((testCase) => {
      it(`${testCase.name} : ${testCase.methodName} ${componentName} - ${testCase.status}`, async () => {
        let mockResponse = {};
        if (testCase.mockData) {
          testCase.mockData.forEach((mocks) => {
            mockResponse[mocks.method] = {...mockResponse[mocks.method], ...mocks.calls};
            axios[mocks.method].mockImplementation((url) => {
              const mock = mockResponse[mocks.method][url];
              if (mock) {
                if (mock.status < 300) {
                  return Promise.resolve(mock.response);
                } else return Promise.reject(mock.response);
              } else {
                return Promise.resolve({});
              }
            });
          });
        }
        const component = VueTestUtils.mount(testComponents[componentName], testCase.options);
        for (let j = 0; j < testCase.steps.length; j++) {
          let step = testCase.steps[j];
          step.actions.forEach(async (action) => {
            let control = component.find(action.selector);
            switch (action.action) {
              case "input":
                control.setValue(action.options.value);
                break;
              default:
                control.trigger(action.action);
                break;
            }
            await component.vm.$nextTick();
          });

          await flushPromises();
          await component.vm.$nextTick();
          step.expectations.forEach((ex) => {
            switch (ex.type) {
              case "axios":
                expect(mockAxios[ex.method]).toHaveBeenCalledWith(
                  ex.url,
                  ex.request
                );
                break;
              case "control":
                var actualSelector = component.find(ex.selector);
                switch (ex.property) {
                  case "innerText":
                    var actual = actualSelector.text();
                    expect(actual).toBe(ex.options.text);
                    break;
                  case "exists":
                    expect(actualSelector.exists()).toBeTruthy();
                    break;
                  case "disabled":
                    expect(
                      actualSelector.is("[" + ex.options.expected + "]")
                    ).toBe(true);
                    break;
                  case "hasAttribute":
                    expect(
                      actualSelector.is("[" + ex.options.expected + "]")
                    ).toBe(true);
                    break;
                  case "doesNotHaveAttribute":
                    expect(
                      actualSelector.is("[" + ex.options.expected + "]")
                    ).toBe(false);
                    break;
                }
                break;
            }
          });
        }
      });
    });
  });
}