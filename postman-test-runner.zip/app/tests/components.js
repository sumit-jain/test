import sample_vue from "../src/components/sample-vue.vue";

export { sample_vue }; 