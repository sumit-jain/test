
module.exports = {
  moduleFileExtensions: [
    "js",
    // tell Jest to handle `*.vue` files
    "vue"
  ],



  transform: {
    // process `*.vue` files with `vue-jest`
    "^.+\\.js$": "babel-jest",
    '.+\\.(css|styl|less|sass|scss|svg|png|jpg|ttf|woff|woff2)$': 'jest-transform-stub',
    ".*\\.vue$": "vue-jest"
  },

  testMatch: ["**/tests/*.spec.js"],
  collectCoverage: true,
  collectCoverageFrom: ["src/**/*.vue", "!src/main.vue"],
  coverageReporters: ["lcov", "html"],
  setupFilesAfterEnv: ["jest-expect-message"],
  testResultsProcessor: "./node_modules/jest-junit-reporter"
};
