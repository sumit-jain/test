var route_config = {}

var config = require('./config');

route_config.ServiceKey = {
  sample: {
    BaseURL: config.BASE_API,
    WrappedResponse: true,
    GET: {
      "user": {
        Path: "/user?name={name}&error={error}",
        Header:
          "Accept|application/json#ContentType|application/json#user-id|_REPLACE({user-id})"
      }
    }
  }
};

module.exports = route_config;
